#include <stdio.h>
#include <string.h>

typedef struct {
    char label[10];
    int address;
} Symbol;

void generateRelocationAndLinkTables(Symbol symbols[], int symbolCount) {
    FILE *relocationTableOutput = fopen("relocation_table.txt", "w");
    FILE *linkTableOutput = fopen("link_table.txt", "w");

    if (!relocationTableOutput || !linkTableOutput) {
        perror("Error creating output files");
        return;
    }

    // Write Relocation Table Header (Addresses Only)
    fprintf(relocationTableOutput, "Address\n");

    // Only output addresses for the relocatable symbols
    for (int i = 0; i < symbolCount; i++) {
        if (strcmp(symbols[i].label, "LOOP") == 0 || 
            strcmp(symbols[i].label, "INNER") == 0 || 
            strcmp(symbols[i].label, "SKIP") == 0 || 
            strcmp(symbols[i].label, "ENDLOOP") == 0) {
            fprintf(relocationTableOutput, "%d\n", symbols[i].address);
        }
    }

    // Write Link Table Header (Only include ARR as the globally defined variable)
    fprintf(linkTableOutput, "Label\tType\tAddress\n");
    for (int i = 0; i < symbolCount; i++) {
        if (strcmp(symbols[i].label, "ARR") == 0) {
            fprintf(linkTableOutput, "%s\tPD\t%d\n", symbols[i].label, symbols[i].address);
        }
    }

    fclose(relocationTableOutput);
    fclose(linkTableOutput);
}

int main() {
    Symbol symbols[] = {
        {"LOOP", 104},
        {"INNER", 110},
        {"SKIP", 118},
        {"ENDLOOP", 128},
        {"ONE", 200},
        {"ZERO", 201},
        {"N", 202},
        {"COUNT", 203},
        {"ARR", 204},      // ARR is the global variable to be added to the link table
    };
    int symbolCount = sizeof(symbols) / sizeof(symbols[0]);

    generateRelocationAndLinkTables(symbols, symbolCount);

    printf("Relocation table and link table generated.\n");
    return 0;
}
